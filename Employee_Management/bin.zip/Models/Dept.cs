﻿namespace Employee_Management.Models
{
    public enum Dept
    {
        None,
        HR,
        IT,
        Payroll
    }
}
